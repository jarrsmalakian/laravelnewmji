<?php $__env->startSection('content'); ?>
    <section class="section" id="features">
        <div class="container">
            <div class="row">
                <div class="section-heading">
                    <h2>Halaman <em>karir</em></h2>
                    <img src="<?php echo e(asset('assets/images/line-dec.png')); ?>" alt="waves" />
                    <p>Under Construction</p>
                </div>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fixlpkmji\resources\views/menu/karir.blade.php ENDPATH**/ ?>