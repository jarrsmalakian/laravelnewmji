

<?php $__env->startSection('content'); ?>
    <section class="section" id="features">
        <div class="container">
            <div class="row">
                <div class="section-heading">
                    <h2>Informasi <em>Penting</em></h2>
                    <img src="<?php echo e(asset('assets/images/line-dec.png')); ?>" alt="waves" />
                </div>
            </div>
            <div class="container">
                <ul class="features-items">
                    <li class="feature-item">
                        <div class="right-content">
                            <h4>Iron Working</h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur
                                adipisicing elit. Nostrum fuga
                                reprehenderit totam. Maxime, architecto.
                                Provident exercitationem, repellendus
                                ullam, sequi, voluptates a dolores
                                laboriosam commodi nulla impedit
                                aperiam. Enim, sapiente quae.
                            </p>
                        </div>
                    </li>
                    <li class="feature-item">
                        <div class="right-content">
                            <h4>Casting</h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur
                                adipisicing elit. Assumenda, dicta quam
                                laudantium magnam explicabo impedit
                                ducimus, sed suscipit voluptates omnis
                                non magni labore laboriosam eaque hic
                                corporis laborum recusandae earum!
                            </p>
                        </div>
                    </li>
                    <li class="feature-item">
                        <div class="right-content">
                            <h4>Plating</h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur,
                                adipisicing elit. Magni, deleniti!
                                Voluptatibus molestias quas voluptatem
                                cupiditate omnis. Ut numquam, voluptates
                                unde placeat, id, tempore vel totam
                                porro similique ea officia culpa. > for
                                images and video background used in this
                                HTML template.
                            </p>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-lg-6">
                <ul class="features-items">
                    <li class="feature-item">
                        <div class="right-content">
                            <h4>Konstruksi</h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur
                                adipisicing elit. Fuga, amet? Unde
                                dolor, velit iure harum odio error
                                delectus autem, maxime ut omnis
                                necessitatibus. Et, ratione unde!
                                Impedit quas obcaecati cumque.
                            </p>
                        </div>
                    </li>
                    <li class="feature-item">
                        <div class="right-content">
                            <h4>Pertanian &amp; Peternakan</h4>
                            <p>
                                Lorem ipsum dolor sit amet consectetur
                                adipisicing elit. Saepe, repellat
                                commodi. Maxime molestias debitis dicta
                                illum, placeat suscipit! Molestias
                                voluptate dicta ipsum quos. Distinctio
                                placeat dolores dolore minima
                                dignissimos consequuntur.
                            </p>
                        </div>
                    </li>
                    <li class="feature-item">
                        <div class="right-content">
                            <h4>Garmen</h4>
                            <p>
                                Lorem ipsum dolor sit, amet consectetur
                                adipisicing elit. Eos, in. Eligendi
                                voluptatum provident quo nemo!
                                Repudiandae voluptate esse unde quae
                                doloribus nisi cupiditate laborum
                                tempore, nam harum debitis facilis
                                explicabo.
                            </p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fixlpkmji\resources\views/menu/informasi.blade.php ENDPATH**/ ?>