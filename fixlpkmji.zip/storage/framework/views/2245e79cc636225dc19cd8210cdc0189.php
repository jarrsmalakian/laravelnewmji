

<?php $__env->startSection('content'); ?>
    <section class="section" id="features">
        <div class="container">
            <div class="row">
                <div class="section-heading">
                    <h2>Data<em> Siswa</em></h2>
                    <img src="<?php echo e(asset('assets/images/line-dec.png')); ?>" alt="waves" />
                    <button type="button" class="btn btn-sm btn-primary">
                        <i class="fas fa-plus-circle"></i> Siswa Baru
                    </button>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fixlpkmji\resources\views/students/data.blade.php ENDPATH**/ ?>